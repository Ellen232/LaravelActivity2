<!DOCTYPE html>
<html>
<head>
	<title>Contact Page</title>
<link href="/css/style.css" rel="stylesheet">
<style>
.container{
	margin-left: 40px;
	padding-top: 45px;
			
}

.info{
	margin: 0px;
	border: 1px solid white;
	border-radius: 10px;
	float: left;
	width: 380px;
	margin-left: 30px;
}


.desc
{
	padding: 15px;
	text-align: center;
	color: white;
	font-size: 18px;
}


.logo
{
   margin-top:5px;
}

.header
{
  padding:10px;
  color:#484848;
  font-size:20px;
  height:150px;
  margin-top: 10px;
  margin-bottom:0px;
}
span
{ 
	margin-top: 0px;
	font-size: 15px;
	color: white;
}
.right{
 float:right; 
 margin-top:-137px;
}
</style>
</head>

<header>
		<div class="main">
			<ul>
				<li> <a href="http://localhost:8000/home">HOME</a></li>
				<li> <a href="http://localhost:8000/about"> ABOUT US</a></li>
				<li> <a href="http://localhost:8000/contact"> CONTACT</a></li>
				<li> <a href="http://localhost:8000/login"> LOGIN</a></li>
				<li> <a href="http://localhost:8000/register"> REGISTER</a></li>		
			</ul>
		</div>
		<div id="container">
		<div class="header">
			<span>&nbsp;Team MaDaLe</span><div class="logo"><img src="img/mde.png" width="100" height="90" class="left">
			</div>
		</div>
	</header>
<br>
<body>
		<header>
		<center>
		<h2>CONTACTS</h2>
		</center>
	</header>
	
	<div class="container">
			<div class="info">
				<div class="desc"><b>RAMOS, ELLEN O.</b>
				<br>
				Phone#: +639270857591
				<br>
				Address: Poblacion, Balungao, Pangasinan
				<br>
				Github: Ellen232
				</div>
			</div>

			<div class="info">
				
				<div class="desc"><b>ORGANISTA, DANIEL C.</b>
				<br>
				Phone#: +639770777470
				<br>
				Address: San Jose, Urdaneta City, Pangasinan
				<br>
				Github: organistadaniel
				</div>
			</div>

			<div class="info">
				<div class="desc"><b>MERCADO, MA. JESUSA B.</b>
				<br>
				Phone#: +639478636268
				<br>
				Address: Calepaan, Asingan, Pangasinan
				<br>
				Github: majesusamercado
				</div>
			</div>

		</div>

	<br><br><br><br><br><br><br><br><br><br><br><br><br>
<footer>
	<center>
		BSIT 3 - BLOCK 5
		<br>
		C265-C266
	</center>
</footer>
</body>
</html>