<!DOCTYPE html>
<html>
<head>
	<title>Home Page</title>

		<link href="/css/style.css" rel="stylesheet">
		<link rel="icon" href="img/mde.png" type="image">
<style>
.title{
	color: black;
	table-layout: auto;
	width:1000px;
	height: 255px;
	padding-top: 5px;
	padding-bottom: 0px;
	font-size: 16px;
	text-align: center;
	border:2px solid white;
	border-collapse: collapse;
	border-radius: 30px 30px 30px 30px;
}
h3{
	color: white;
}
.logo
{
   margin-top:5px;
}

.header
{
  padding:10px;
  color:#484848;
  font-size:20px;
  height:150px;
  margin-top: 10px;
  margin-bottom:0px;
}
span
{ 
	margin-top: 0px;
	font-size: 15px;
	color: white;
}
.right{
 float:right; 
 margin-top:-137px;
}

</style>
</head>

<body>

	<header>
		<div class="main">
			<ul>
				<li> <a href="http://localhost:8000/home">HOME</a></li>
				<li> <a href="http://localhost:8000/about"> ABOUT US</a></li>
				<li> <a href="http://localhost:8000/contact"> CONTACT</a></li>
				<li> <a href="http://localhost:8000/login"> LOGIN</a></li>
				<li> <a href="http://localhost:8000/register"> REGISTER</a></li>		
			</ul>
		</div>
			<div id="container">
		<div class="header">
			<span>&nbsp;Team MaDaLe</span><div class="logo"><img src="img/mde.png" width="100" height="90" class="left">
			</div>
		</div>
	</header>

		<br><br>
		<center>
		<div class="title">
			<h1>MaDaLe Group Page</h1> <br>
			<h3>Welcome To Our Group Page<br>
			We work hard to finish this simple creation of our group page. This group page has login and register page and it shows brief information about us.</h3>
		</div>
		</center>

<br><br><br><br><br><br><br><br><br>

<footer>
	<center>
		BSIT 3 - BLOCK 5
		<br>
		C265-C266
	</center>
</footer>

</body>
</html>